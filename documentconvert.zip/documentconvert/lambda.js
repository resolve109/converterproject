const { PDFDocument } = require('pdf-lib');

exports.handler = async (event) => {
    try {
        const inputFileType = event.fileType;
        const inputFileBuffer = Buffer.from(event.fileContent, 'base64'); // Decode base64 content

        let htmlContent;

        if (inputFileType === 'doc' || inputFileType === 'docx') {
            // You can handle DOC/DOCx to HTML conversion here if needed
            // For simplicity, let's assume you have HTML content
            htmlContent = inputFileBuffer.toString('utf-8');
        } else if (inputFileType === 'html') {
            // Use HTML content directly
            htmlContent = inputFileBuffer.toString('utf-8');
        }

        // Create a PDF document and add content
        const pdfDoc = await PDFDocument.create();
        const page = pdfDoc.addPage([612, 792]); // Letter size
        const pdfImage = await pdfDoc.embedPng(Buffer.from(htmlContent));

        // Add image to the page
        page.drawImage(pdfImage, {
            x: 0,
            y: 0,
            width: 612,
            height: 792,
        });

        // Serialize the PDF document to bytes
        const pdfBytesFinal = await pdfDoc.save();

        return {
            statusCode: 200,
            body: pdfBytesFinal.toString('base64'),
        };
    } catch (error) {
        return {
            statusCode: 500,
            error: error.message,
        };
    }
};
